enum
{
	_DUMMY_ELEMENT_
};
