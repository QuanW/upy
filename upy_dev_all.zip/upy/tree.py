tree="""
|____init__.py
|____colors.py
|____hostHelper.py
|____uiAdaptor.py
|____autodeskmaya
| |______init__.py
| |____helperMaya.py
| |____mayaUI.py
|____blender
| |______init__.py
| |____v249
| | |______init__.py
| | |____blenderHelper.py
| | |____blenderUI.py
| |____v257
| | |______init__.py
| | |____blenderHelper.py
| | |____blenderUI.py
|____cinema4d
| |______init__.py
| |____c4dUI.py
| |____helperC4D.py
|____dejavuTk
| |______init__.py
| |____helperDejaVu.py
| |____tkUI.py
|____qtUI.py
"""
print (tree)
